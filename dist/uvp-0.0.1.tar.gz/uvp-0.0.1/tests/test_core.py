"""
Tests for core.py functionality.
"""

from uvp import core


def test_core_imports():
    """Test that core module imports correctly."""
    assert core is not None


# Add more specific tests for core functionality as needed
