"""UVP - All-in-one tool for managing and deploying Python projects."""

from uvp.core import __version__, app

__all__ = ["app", "__version__"]
